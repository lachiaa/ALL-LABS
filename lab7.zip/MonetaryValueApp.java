import java.util.Scanner;

public class MonetaryValueApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        while (true) {
            System.out.print("Enter a monetary amount (or type 'quit' to exit): ");
            input = scanner.nextLine();

            if (input.equalsIgnoreCase("quit")) {
                break;
            }

            try {
                double amount = Double.parseDouble(input);
                MonetaryValue monetaryValue = new MonetaryValue(amount);
                monetaryValue.calculateChange();
            } catch (NumberFormatException e) {
                System.out.println("EXCEPTION: Invalid input");
            }
        }

        scanner.close();
    }
}