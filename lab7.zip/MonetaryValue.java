public class MonetaryValue {
    private double amount;

    public MonetaryValue(double amount) {
        this.amount = amount;
    }

    public void calculateChange() {
        int remainingCents = (int) Math.round(amount * 100); // Convert to cents

        int tenDollarBills = remainingCents / 1000;
        remainingCents %= 1000;

        int fiveDollarBills = remainingCents / 500;
        remainingCents %= 500;

        int oneDollarBills = remainingCents / 100;
        remainingCents %= 100;

        int quarters = remainingCents / 25;
        remainingCents %= 25;

        int dimes = remainingCents / 10;
        remainingCents %= 10;

        int nickels = remainingCents / 5;
        remainingCents %= 5;

        int pennies = remainingCents;

        // Print result
        System.out.printf("%d ten dollar bills%n", tenDollarBills);
        System.out.printf("%d five dollar bills%n", fiveDollarBills);
        System.out.printf("%d one dollar bills%n", oneDollarBills);
        System.out.printf("%d quarters%n", quarters);
        System.out.printf("%d dimes%n", dimes);
        System.out.printf("%d nickels%n", nickels);
        System.out.printf("%d pennies%n", pennies);
    }
}