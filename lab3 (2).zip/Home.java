public class Home extends Policy {
    private int squareFootage;
    private double dwelling;
    private double contents;
    private double liability;

    public Home(String firstName, String lastName, int squareFootage, double dwelling, double contents, double liability) {
        super(firstName, lastName);
        this.squareFootage = squareFootage;
        this.dwelling = dwelling;
        this.contents = contents;
        this.liability = liability;
    }

    @Override
    public double computeCommission() {
        // Commission calculation: 5% of dwelling + 10% of contents + 15% of liability
        return (dwelling * 0.05) + (contents * 0.10) + (liability * 0.15);
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Footage: " + squareFootage);
        System.out.printf("Dwelling: $%.2f%n", dwelling);
        System.out.printf("Contents: $%.2f%n", contents);
        System.out.printf("Liability: $%.2f%n", liability);
        System.out.printf("Commission: $%.2f%n", computeCommission());
    }
}