public class Auto extends Policy {
    private String make;
    private String model;
    private double liability;
    private double collision;

    public Auto(String firstName, String lastName, String make, String model, double liability, double collision) {
        super(firstName, lastName);
        this.make = make;
        this.model = model;
        this.liability = liability;
        this.collision = collision;
    }

    @Override
    public double computeCommission() {
        // Commission calculation: 10% of liability + 20% of collision
        return (liability * 0.10) + (collision * 0.20);
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.printf("Liability: $%.2f%n", liability);
        System.out.printf("Collision: $%.2f%n", collision);
        System.out.printf("Commission: $%.2f%n", computeCommission());
    }
}