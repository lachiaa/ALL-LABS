public class Life extends Policy {
    private int age;
    private double term;

    public Life(String firstName, String lastName, int age, double term) {
        super(firstName, lastName);
        this.age = age;
        this.term = term;
    }

    @Override
    public double computeCommission() {
        // Commission calculation: 20% of term
        return term * 0.20;
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Age: " + age);
        System.out.printf("Term: $%.2f%n", term);
        System.out.printf("Commission: $%.2f%n", computeCommission());
    }
}