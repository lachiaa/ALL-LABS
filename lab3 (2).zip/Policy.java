public abstract class Policy {
    protected String firstName;
    protected String lastName;

    public Policy(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public abstract double computeCommission();

    public void displayInfo() {
        System.out.println("Name: " + firstName + " " + lastName);
    }
}