public class Task implements Priority {
    private String taskDescription;
    private int priority;

    public Task(String taskDescription, int priority) {
        this.taskDescription = taskDescription;
        setPriority(priority); // Use the setter to ensure priority is valid
    }

    @Override
    public void setPriority(int priority) {
        if (priority < 1 || priority > 5) {
            throw new IllegalArgumentException("Priority must be between 1 and 5.");
        }
        this.priority = priority;
    }

    @Override
    public int getPriority() {
        return priority;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    @Override
    public String toString() {
        return String.format("%-20s priority: %d", taskDescription, priority);
    }
}