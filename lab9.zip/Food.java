public class Food {
    private String name;
    private String foodGroup;
    private int calories;
    private double dailyPercentage;
    private Food next;

    public Food(String name, String foodGroup, int calories, double dailyPercentage) {
        this.name = name;
        this.foodGroup = foodGroup;
        this.calories = calories;
        this.dailyPercentage = dailyPercentage;
        this.next = null;
    }

    public String getName() {
        return name;
    }

    public String getFoodGroup() {
        return foodGroup;
    }

    public int getCalories() {
        return calories;
    }

    public double getDailyPercentage() {
        return dailyPercentage;
    }

    public Food getNext() {
        return next;
    }

    public void setNext(Food next) {
        this.next = next;
    }
}