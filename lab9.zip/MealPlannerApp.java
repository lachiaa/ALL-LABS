import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MealPlannerApp {
    public static void main(String[] args) {
        FoodList foodList = new FoodList();
        loadFoodsFromFile(foodList);

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("---------------------------------");
            System.out.println("Welcome to Parkland Meal Selector");
            System.out.println("---------------------------------");
            System.out.println("Please select from the following");
            System.out.println("1 - List food database");
            System.out.println("2 - Create meal by manual selection");
            System.out.println("3 - Create meal by random selection");
            System.out.println("4 - Remove foods high in calorie");
            System.out.println("5 - Exit");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    foodList.listFoods();
                    break;
                case 2:
                    foodList.createMealManually(scanner);
                    break;
                case 3:
                    foodList.createMealRandomly();
                    break;
                case 4:
                    System.out.print("Enter calorie limit: ");
                    int calorieLimit = scanner.nextInt();
                    foodList.removeHighCalorieFoods(calorieLimit);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void loadFoodsFromFile(FoodList foodList) {
        try {
            Scanner fileScanner = new Scanner(new File("foods.txt"));
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(" ");
                if (parts.length == 4) {
                    String name = parts[0];
                    String foodGroup = parts[1];
                    int calories = Integer.parseInt(parts[2]);
                    double dailyPercentage = Double.parseDouble(parts[3]);
                    Food food = new Food(name, foodGroup, calories, dailyPercentage);
                    foodList.addFood(food);
                }
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: Food file not found.");
        } catch (Exception e) {
            System.out.println("Error reading food data: " + e.getMessage());
        }
    }
}