import java.util.Random;

public class FoodList {
    private Food head;

    public FoodList() {
        this.head = null;
    }

    public void addFood(Food food) {
        if (head == null) {
            head = food;
        } else {
            Food current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(food);
        }
    }

    public void listFoods() {
        System.out.printf("%-20s %-15s %-10s %-20s%n", "Name", "Food Group", "Calories", "Daily percentage");
        System.out.println("============================================================================");
        Food current = head;
        while (current != null) {
            System.out.printf("%-20s %-15s %-10d %-20.2f%n", current.getName(), current.getFoodGroup(), current.getCalories(), current.getDailyPercentage());
            current = current.getNext();
        }
    }

    public Food findFood(String name) {
        Food current = head;
        while (current != null) {
            if (current.getName().equalsIgnoreCase(name)) {
                return current;
            }
            current = current.getNext();
        }
        return null;
    }

    public void createMealManually(java.util.Scanner scanner) {
        Food[] selectedFoods = new Food[3];
        for (int i = 0; i < 3; i++) {
            System.out.print("Enter food name: ");
            String name = scanner.nextLine();
            Food food = findFood(name);
            while (food == null) {
                System.out.printf("Food %s not in database, try again%n", name);
                System.out.print("Enter food name: ");
                name = scanner.nextLine();
                food = findFood(name);
            }
            selectedFoods[i] = food;
        }
        printMeal(selectedFoods);
    }

    public void createMealRandomly() {
        Random random = new Random();
        Food[] selectedFoods = new Food[3];
        Food current = head;
        int count = 0;

        while (current != null) {
            count++;
            current = current.getNext();
        }

        for (int i = 0; i < 3; i++) {
            int index = random.nextInt(count);
            current = head;
            for (int j = 0; j < index; j++) {
                current = current.getNext();
            }
            selectedFoods[i] = current;
        }
        printMeal(selectedFoods);
    }

    private void printMeal(Food[] foods) {
        int totalCalories = 0;
        double totalDailyPercentage = 0;

        System.out.println("===============================");
        System.out.print("Your selected meal\nFoods: ");
        for (int i = 0; i < foods.length; i++) {
            System.out.print(foods[i].getName() + " ");
            totalCalories += foods[i].getCalories();
            totalDailyPercentage += foods[i].getDailyPercentage();
        }
        System.out.printf("%nTotal calorie count: %d%n", totalCalories);
        System.out.printf("Total daily percentage: %.2f%%%n", totalDailyPercentage * 100);
        System.out.println("===============================");
    }

    public void removeHighCalorieFoods(int calorieLimit) {
        Food current = head;
        Food previous = null;

        while (current != null) {
            if (current.getCalories() > calorieLimit) {
                if (previous == null) {
                    head = current.getNext();
                } else {
                    previous.setNext(current.getNext());
                }
            } else {
                previous = current;
            }
            current = current.getNext();
        }
    }
}