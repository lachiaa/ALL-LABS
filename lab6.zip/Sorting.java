public class Sorting {
    public static <T extends Comparable<T>> void selectionSort(T[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int maxIndex = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j].compareTo(array[maxIndex]) > 0) {
                    maxIndex = j;
                }
            }
            // Swap
            T temp = array[i];
            array[i] = array[maxIndex];
            array[maxIndex] = temp;
        }
    }
}