import java.util.Scanner;

public class Gradebook {
    private Student[] students;
    private int count;

    public Gradebook(int size) {
        students = new Student[size];
        count = 0;
    }

    public void addStudent(String firstName, String lastName, int score) {
        if (count < students.length) {
            students[count++] = new Student(firstName, lastName, score);
        } else {
            System.out.println("Gradebook is full.");
        }
    }

    public void sortStudents() {
        Sorting.selectionSort(students);
    }

    public void printStudents() {
        for (int i = 0; i < count; i++) {
            System.out.println(students[i]);
        }
    }
}