public class Life extends Policy {
    private int age;
    private double term;

    public Life(String firstName, String lastName, int age, double term) {
        super(firstName, lastName);
        this.age = age;
        this.term = term;
    }

    @Override
    public double computeCommission() {
        // Commission calculation: 20% of term
        return term * 0.20;
    }

    @Override
    public String toString() {
        return "Life Policy\n-----------\n" +
               "Name: " + firstName + " " + lastName + "\n" +
               "Age: " + age + "\n" +
               "Term: $" + String.format("%.2f", term) + "\n" +
               "Commission: $" + String.format("%.2f", computeCommission()) + "\n";
    }
}