public class Auto extends Policy {
    private String make;
    private String model;
    private double liability;
    private double collision;

    public Auto(String firstName, String lastName, String make, String model, double liability, double collision) {
        super(firstName, lastName);
        this.make = make;
        this.model = model;
        this.liability = liability;
        this.collision = collision;
    }

    @Override
    public double computeCommission() {
        // Commission calculation: 10% of liability + 20% of collision
        return (liability * 0.10) + (collision * 0.20);
    }

    @Override
    public String toString() {
        return "Auto Policy\n-----------\n" +
               "Name: " + firstName + " " + lastName + "\n" +
               "Make: " + make + "\n" +
               "Model: " + model + "\n" +
               "Liability: $" + String.format("%.2f", liability) + "\n" +
               "Collision: $" + String.format("%.2f", collision) + "\n" +
               "Commission: $" + String.format("%.2f", computeCommission()) + "\n";
    }
}