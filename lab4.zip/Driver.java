public class Driver {
    public static void main(String[] args) {
        // Create commission calculator
        CommissionCalculator calc = new CommissionCalculator();

        // Run commission calculator
        calc.Run();
    }
}