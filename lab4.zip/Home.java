public class Home extends Policy {
    private int squareFootage;
    private double dwelling;
    private double contents;
    private double liability;

    public Home(String firstName, String lastName, int squareFootage, double dwelling, double contents, double liability) {
        super(firstName, lastName);
        this.squareFootage = squareFootage;
        this.dwelling = dwelling;
        this.contents = contents;
        this.liability = liability;
    }

    @Override
    public double computeCommission() {
        // Commission calculation: 5% of dwelling + 10% of contents + 15% of liability
        return (dwelling * 0.05) + (contents * 0.10) + (liability * 0.15);
    }

    @Override
    public String toString() {
        return "Home Policy\n-----------\n" +
               "Name: " + firstName + " " + lastName + "\n" +
               "Footage: " + squareFootage + "\n" +
               "Dwelling: $" + String.format("%.2f", dwelling) + "\n" +
               "Contents: $" + String.format("%.2f", contents) + "\n" +
               "Liability: $" + String.format("%.2f", liability) + "\n" +
               "Commission: $" + String.format("%.2f", computeCommission()) + "\n";
    }
}