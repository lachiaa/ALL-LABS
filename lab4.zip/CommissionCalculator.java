import java.util.ArrayList;
import java.util.Scanner;

public class CommissionCalculator {
    private ArrayList<Policy> policies;

    public CommissionCalculator() {
        // Initialize the ArrayList for storing policies
        policies = new ArrayList<>();
    }

    public void Run() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("-----------------------------");
            System.out.println("Welcome to Parkland Insurance");
            System.out.println("-----------------------------");
            System.out.println("Enter any of the following:");
            System.out.println("       1) Enter auto insurance policy information");
            System.out.println("       2) Enter home insurance policy information");
            System.out.println("       3) Enter life insurance policy information");
            System.out.println("       4) Print all sales entered");
            System.out.println("       5) Quit");

            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter first name of insured: ");
                    String autoFirstName = scanner.nextLine();
                    System.out.print("Enter last name of insured: ");
                    String autoLastName = scanner.nextLine();
                    System.out.print("Enter make of vehicle: ");
                    String make = scanner.nextLine();
                    System.out.print("Enter model of vehicle: ");
                    String model = scanner.nextLine();
                    System.out.print("Enter amount of liability: $");
                    double autoLiability = scanner.nextDouble();
                    System.out.print("Enter amount of collision: $");
                    double autoCollision = scanner.nextDouble();
                    policies.add(new Auto(autoFirstName, autoLastName, make, model, autoLiability, autoCollision));
                    break;

                case 2:
                    System.out.print("Enter first name of insured: ");
                    String homeFirstName = scanner.nextLine();
                    System.out.print("Enter last name of insured: ");
                    String homeLastName = scanner.nextLine();
                    System.out.print("Enter house square footage: ");
                    int squareFootage = scanner.nextInt();
                    System.out.print("Enter amount of dwelling: $");
                    double dwelling = scanner.nextDouble();
                    System.out.print("Enter amount of contents: $");
                    double contents = scanner.nextDouble();
                    System.out.print("Enter amount of liability: $");
                    double homeLiability = scanner.nextDouble();
                    policies.add(new Home(homeFirstName, homeLastName, squareFootage, dwelling, contents, homeLiability));
                    break;

                case 3:
                    System.out.print("Enter first name of insured: ");
                    String lifeFirstName = scanner.nextLine();
                    System.out.print("Enter last name of insured: ");
                    String lifeLastName = scanner.nextLine();
                    System.out.print("Enter age of insured: ");
                    int age = scanner.nextInt();
                    System.out.print("Enter amount of term: $");
                    double term = scanner.nextDouble();
                    policies.add(new Life(lifeFirstName, lifeLastName, age, term));
                    break;

                case 4:
                    // List all policies
                    for (Policy policy : policies) {
                        // Compute commission
                        double commission = policy.computeCommission();
                        // Print the policy
                        System.out.println(policy);
                    }
                    break;

                case 5:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}