import java.util.Scanner;

public class GCDApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter positive integer as numerator: ");
        int numerator = scanner.nextInt();

        System.out.print("Enter positive integer as denominator: ");
        int denominator = scanner.nextInt();

        try {
            RationalNumber rationalNumber = new RationalNumber(numerator, denominator);
            int gcd = rationalNumber.getGCD();
            System.out.printf("Greatest common denominator of %d/%d is %d%n", numerator, denominator, gcd);
        } catch (IllegalArgumentException e) {
            System.out.println("EXCEPTION: " + e.getMessage());
        }

        scanner.close();
    }
}